variable = str(input("Enter display variable: \n"))

#file output setup
import os.path
fileDirectory = str(os.environ['USERPROFILE'] + "\AppData\LocalLow\Jundroo\SimplePlanes\AircraftDesigns")
completeName = os.path.join(fileDirectory, "GeneratedDotMatrix.xml")

#set stdout to file
import sys
sys.stdout = open(completeName, 'w')

file = '''<Aircraft name="Dot Matrix Test Backup" url="" theme="Custom" size="1.25,1.091647,1.750001" boundsMin="-0.6250001,1.733353,-0.8750003" xmlVersion="6" legacyJointIdentification="false">
  <Assembly>
    <Parts>
      <Part id="1" partType="Cockpit-1" position="5.960464E-08,1.983353,0.375" rotation="0,0,0" drag="0,0,0,0,0,0" materials="7,0" partCollisionResponse="Default" massScale="0" disableAircraftCollisions="true" calculateDrag="false">
        <Cockpit.State primaryCockpit="True" lookBackTranslation="0,0" />
      </Part>
      <Part id="2" partType="Fuselage-Body-1" position="5.960464E-08,2.75,0" rotation="270,0,0" drag="0,0,0,0,0,0" materials="1" scale="1,1,1" partCollisionResponse="Default" massScale="0" disableAircraftCollisions="true" calculateDrag="false">
        <FuelTank.State fuel="0" capacity="0" />
        <Fuselage.State version="2" frontScale="2.5,3.5" rearScale="2.5,3.5" offset="0,0,0.25" deadWeight="0" buoyancy="0" fuelPercentage="0" smoothFront="False" smoothBack="False" cornerTypes="0,0,0,0,0,0,0,0" />
      </Part>
      <Part id="3" partType="AirBrake-1" position="-0.2499999,2.8125,0.5058" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="floor(repeat(abs({0}),10))=1" />
      </Part>
      <Part id="5" partType="AirBrake-1" position="-0.4999999,2.8125,0.2558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))&gt;=2)&amp;(floor(repeat(abs({0}),10))&lt;=4)|(floor(repeat(abs({0}),10))=7))" />
      </Part>
      <Part id="6" partType="AirBrake-1" position="-0.2499999,2.8125,0.2558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=5)" />
      </Part>
      <Part id="7" partType="AirBrake-1" position="-0.4999999,2.8125,0.5058" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=7))" />
      </Part>
      <Part id="8" partType="AirBrake-1" position="-0.4999999,2.8125,0.7558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=5)|(floor(repeat(abs({0}),10))=7)" />
      </Part>
      <Part id="9" partType="AirBrake-1" position="-0.2499999,2.8125,0.7558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=4))" />
      </Part>
      <Part id="10" partType="AirBrake-1" position="-0.4999999,2.8125,0.005800009" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=6)|(floor(repeat(abs({0}),10))=0)" />
      </Part>
      <Part id="11" partType="AirBrake-1" position="-0.2499999,2.8125,0.005800009" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=6)|(floor(repeat(abs({0}),10))=8)|(floor(repeat(abs({0}),10))=9)" />
      </Part>
      <Part id="12" partType="AirBrake-1" position="5.960464E-08,2.8125,0.005800009" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=2)|(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=5)|(floor(repeat(abs({0}),10))=0))" />
      </Part>
      <Part id="13" partType="AirBrake-1" position="5.960464E-08,2.8125,0.7558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!(floor(repeat(abs({0}),10))=4)" />
      </Part>
      <Part id="14" partType="AirBrake-1" position="5.960464E-08,2.8125,0.5058" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=4)" />
      </Part>
      <Part id="15" partType="AirBrake-1" position="5.960464E-08,2.8125,0.2558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=5)" />
      </Part>
      <Part id="16" partType="AirBrake-1" position="0.2500001,2.8125,0.5058" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="floor(repeat(abs({0}),10))=4" />
      </Part>
      <Part id="17" partType="AirBrake-1" position="0.2500001,2.8125,0.7558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!(floor(repeat(abs({0}),10))=1)" />
      </Part>
      <Part id="18" partType="AirBrake-1" position="0.2500001,2.8125,0.2558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=5)|(floor(repeat(abs({0}),10))=7)" />
      </Part>
      <Part id="19" partType="AirBrake-1" position="0.2500001,2.8125,0.005800009" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=5)|(floor(repeat(abs({0}),10))=7)|(floor(repeat(abs({0}),10))=0))" />
      </Part>
      <Part id="20" partType="AirBrake-1" position="0.5000001,2.8125,0.005800009" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=5)|(floor(repeat(abs({0}),10))=9)|(floor(repeat(abs({0}),10))=0)" />
      </Part>
      <Part id="21" partType="AirBrake-1" position="0.5000001,2.8125,0.2558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))&gt;=4)&amp;(floor(repeat(abs({0}),10))&lt;=7)|(floor(repeat(abs({0}),10))=1))" />
      </Part>
      <Part id="22" partType="AirBrake-1" position="0.5000001,2.8125,0.5058" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=5))" />
      </Part>
      <Part id="23" partType="AirBrake-1" position="0.5000001,2.8125,0.7558" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=5)|(floor(repeat(abs({0}),10))=7)" />
      </Part>
      <Part id="24" partType="AirBrake-1" position="-0.4999999,2.8125,-0.2442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=6)|(floor(repeat(abs({0}),10))=8)|(floor(repeat(abs({0}),10))=0)" />
      </Part>
      <Part id="25" partType="AirBrake-1" position="-0.4999999,2.8125,-0.4942" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=2)|(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=7))" />
      </Part>
      <Part id="26" partType="AirBrake-1" position="-0.4999999,2.8125,-0.7442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=2)" />
      </Part>
      <Part id="27" partType="AirBrake-1" position="5.960464E-08,2.8125,-0.2442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=2)|(floor(repeat(abs({0}),10))=4)" />
      </Part>
      <Part id="28" partType="AirBrake-1" position="5.960464E-08,2.8125,-0.4942" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="floor(repeat(abs({0}),10))=1" />
      </Part>
      <Part id="29" partType="AirBrake-1" position="5.960464E-08,2.8125,-0.7442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=7))" />
      </Part>
      <Part id="30" partType="AirBrake-1" position="-0.2499999,2.8125,-0.7442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="floor(repeat(abs({0}),10))!=4" />
      </Part>
      <Part id="31" partType="AirBrake-1" position="-0.2499999,2.8125,-0.4942" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=2)|(floor(repeat(abs({0}),10))=7)" />
      </Part>
      <Part id="32" partType="AirBrake-1" position="-0.2499999,2.8125,-0.2442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=7)" />
      </Part>
      <Part id="33" partType="AirBrake-1" position="0.2500001,2.8125,-0.2442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="floor(repeat(abs({0}),10))=4" />
      </Part>
      <Part id="34" partType="AirBrake-1" position="0.2500001,2.8125,-0.4942" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="floor(repeat(abs({0}),10))=4" />
      </Part>
      <Part id="35" partType="AirBrake-1" position="0.2500001,2.8125,-0.7442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="floor(repeat(abs({0}),10))!=7" />
      </Part>
      <Part id="36" partType="AirBrake-1" position="0.5000001,2.8125,-0.7442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="(floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=2)" />
      </Part>
      <Part id="37" partType="AirBrake-1" position="0.5000001,2.8125,-0.4942" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=2)|(floor(repeat(abs({0}),10))=4)|(floor(repeat(abs({0}),10))=7))" />
      </Part>
      <Part id="38" partType="AirBrake-1" position="0.5000001,2.8125,-0.2442" rotation="0,0,0" drag="0,0,0,0,0,0" materials="0,0" disableAircraftCollisions="true" scale="0.475,0.5,0.475" massScale="0" calculateDrag="false" partCollisionResponse="Default">
        <InputController.State activationGroup="0" invert="false" min="0" max="0.005" input="!((floor(repeat(abs({0}),10))=1)|(floor(repeat(abs({0}),10))=2)|(floor(repeat(abs({0}),10))=7))" />
      </Part>
      <Part id="39" partType="Fuselage-Body-1" position="0,2.7625,0" rotation="270,0,0" drag="0.1667441,0.1667441,2.176,2.176,0.1104601,0.11046" materials="1" scale="1,1,1" partCollisionResponse="Default" massScale="0" disableAircraftCollisions="true" calculateDrag="false">
        <FuelTank.State fuel="0" capacity="0" />
        <Fuselage.State version="2" frontScale="2.5,3.5" rearScale="2.5,3.5" offset="0,0,0.25" deadWeight="0" buoyancy="0" fuelPercentage="0" smoothFront="False" smoothBack="False" cornerTypes="0,0,0,0,0,0,0,0" />
      </Part>
    </Parts>
    <Connections>
      <Connection partA="3" partB="2" attachPointsA="0" attachPointsB="0" />
      <Connection partA="5" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="6" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="7" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="8" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="9" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="10" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="11" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="12" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="13" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="14" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="15" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="16" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="17" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="18" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="19" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="20" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="21" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="22" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="23" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="24" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="25" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="26" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="27" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="28" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="29" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="30" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="31" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="32" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="33" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="34" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="35" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="36" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="37" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="38" partB="2" attachPointsA="0" attachPointsB="2" />
      <Connection partA="2" partB="39" attachPointsA="0" attachPointsB="1" />
    </Connections>
    <Bodies>
      <Body partIds="1" position="0,0,0" rotation="0,0,0" velocity="0,0,0" angularVelocity="0,0,0" />
      <Body partIds="2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39" position="0,0,0" rotation="0,0,0" velocity="0,0,0" angularVelocity="0,0,0" />
    </Bodies>
  </Assembly>
  <Theme name="Custom">
    <Material color="000000" r="0" m="1" s="0" />
    <Material color="FFFFFF" r="0" m="0" s="0" />
    <Material color="001F7F" r="0.3" m="0.5" s="0.83" />
    <Material color="AA2A00" r="0.15" m="0.5" s="0.7" />
    <Material color="3F3F3F" r="0" m="0.65" s="0.08" />
    <Material color="5C0000" r="0" m="0.65" s="0.08" />
    <Material color="FFFFFF" r="0" m="0.65" s="0.08" />
    <Material color="FFF0F0" r="0" m="0.65" s="0.08" />
    <Material color="FF0F0F" r="0" m="0.65" s="0.08" />
    <Material color="AAAAAA" r="0" m="0.65" s="0.08" />
    <Material color="3F3F3F" r="0.15" m="0.5" s="0.7" />
    <Material color="ABABAB" r="0" m="0.65" s="0.08" />
    <Material color="446677" r="0" m="0.65" s="0.08" />
    <Material color="FF1143" r="0" m="0.65" s="0.08" />
    <Material color="FF6A12" r="0" m="0.65" s="0.08" />
    <Material color="000000" r="0" m="0.65" s="0.08" />
    <Material color="FFFFFF" r="0" m="0.65" s="0.08" />
    <Material color="1E1E1E" r="0" m="0.65" s="0.08" />
    <Material color="D0D0D0" r="0" m="0.65" s="0.08" />
  </Theme>
</Aircraft>'''.format(variable)

print(file)

#close file
sys.stdout.close()